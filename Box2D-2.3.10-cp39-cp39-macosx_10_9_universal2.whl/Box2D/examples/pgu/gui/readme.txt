This is the GUI module from Phil's pyGame Utilities:
http://www.imitationpickles.org/pgu/wiki/index